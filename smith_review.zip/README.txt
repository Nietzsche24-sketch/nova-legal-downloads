What’s in this package

1) Smith v Ontario – Application Record (court).pdf — FILE THIS ONE. Index is page 1. Pages: 23.
2) Smith v Ontario – Application Record (searchable).pdf — for reading/searching. Pages: 12.

Checksums (SHA-256)
- court:       ec0fdf23704dfe4017056a468e7ccd4856fdce251c890c477a60b3f1389285ad
- searchable:  3e0e9e6437dec84ec58eb1d05137a87e46800deb2da601e9a1ced20d53a8cfb9
